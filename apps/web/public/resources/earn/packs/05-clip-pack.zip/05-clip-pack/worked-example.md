> Worked example. The business, people and numbers are invented to show the shape of a finished deliverable.

# Clip pack: a 45-minute youth talk on saving money

## Clips
Moments noted: the 50-cent jar story, three rules for a first pay cheque, a question from the audience.

### Clip 1: The 50-cent jar
04:10 – 04:52 · why it stands alone: a complete story with a clear ending

### Clip 2: Three rules for your first pay
17:30 – 18:25 · why it stands alone: a numbered list people can screenshot

### Clip 3: "What if my family needs the money?"
31:05 – 31:58 · why it stands alone: a real question and a short honest answer

## Captions
For 16–25-year-olds on Facebook Reels and WhatsApp Status
- Clip 1 hook: She saved one coin a day for a year · caption: Sister Rumbi's 50-cent jar, and what she bought with it.
- Clip 2 hook: Three rules before you spend your first pay · caption: Pay yourself first, wait a week for big buys, tell one person your plan.
- Clip 3 hook: When family asks for your savings · caption: A question from the floor and the pastor's answer, unedited.

## Rights log
- Video owner: the youth pastor, written yes on WhatsApp on 2 November
- Music in the background: none in the chosen clips
- Other people seen or heard: the person asking in clip 3 agreed in writing; her face is cropped out
- Logos or other people's content on screen: a bank poster at 17:40, cropped out to be safe

## Approval sheet
- Clip 1: approved by the youth pastor on 5 November · changes: none
- Clip 2: approved by the youth pastor on 5 November · changes: fix the spelling of "cheque"
- Clip 3: approved by the youth pastor on 6 November · changes: start two seconds later

## Boundary
- Nothing is posted before the owner approves it. No invented quotes.
- No faces of anyone under 18 without a parent's written yes.
