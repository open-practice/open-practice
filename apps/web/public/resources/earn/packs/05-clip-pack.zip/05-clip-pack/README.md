# Build 05 · Turn one recording into a clip pack

Creators and small organisations record long videos and never cut them down. A clip pack turns one long recording into a few short, captioned moments, with a rights log and an approval sheet so nothing goes out without permission. You plan the pack here; cut the clips in any free editor.

## You will make
- Clips
- Captions
- Rights log
- Approval sheet

## Steps
1. Read worked-example.md first. It shows a finished deliverable for an invented business.
2. Open the workshop at https://open-practice.open-practice.workers.dev/earn/builds/clip-pack/ or use template.md offline. Replace every [[blank]] with your own work.
3. Do the real-world part: the interviews, tests, approvals or hand counts the template asks for. Log each one in evidence-log.csv.
4. Run the checks in the workshop, or go through checklist.md by hand. Fix one thing at a time.
5. Fill in offer-contract.md and pick five personalised prospects in sales-practice.csv. No mass messages.
6. Record time and costs in economics.csv. Keep everything: it is your evidence.

## What is in this pack
- template.md: the blank deliverable
- worked-example.md: a finished example (invented business, labelled)
- checklist.md: the same checks the workshop runs, in plain words
- approval-sheet.csv: a blank log for this build
- rights-log.csv: a blank log for this build
- offer-contract.md: the 10 artifacts every build ends with
- sales-practice.csv, evidence-log.csv, economics.csv

## Honest limits
This pack teaches a way of working. It does not promise income. Use invented practice data until you have a real client, and get permission before using anyone else's data, media or name.

Open Practice · Earn by Doing · CC BY 4.0 · https://open-practice.open-practice.workers.dev/earn/builds/clip-pack/
