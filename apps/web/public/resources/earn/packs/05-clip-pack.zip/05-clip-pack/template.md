# Clip pack: [[What is the long video?]]

## Clips
Moments noted:
[[Moments you noted (timestamp + what happens)]]

### Clip 1: [[short title]]
[[start mm:ss]] – [[end mm:ss]] · why it stands alone: [[reason]]

### Clip 2: [[short title]]
[[start]] – [[end]] · why it stands alone: [[reason]]

### Clip 3: [[short title]]
[[start]] – [[end]] · why it stands alone: [[reason]]

## Captions
For [[Who should the clips reach?]] on [[Where will they be posted?]]
- Clip 1 hook: [[under 12 words]] · caption: [[what was actually said, no exaggeration]]
- Clip 2 hook: [[hook]] · caption: [[caption]]
- Clip 3 hook: [[hook]] · caption: [[caption]]

## Rights log
- Video owner: [[Who owns it, and did they say yes in writing?]]
- Music in the background: [[none / whose / allowed?]]
- Other people seen or heard: [[who, and did they agree?]]
- Logos or other people's content on screen: [[what, and is it allowed?]]

## Approval sheet
- Clip 1: approved by [[name or role]] on [[date]] · changes: [[none / what]]
- Clip 2: approved by [[name or role]] on [[date]] · changes: [[changes]]
- Clip 3: approved by [[name or role]] on [[date]] · changes: [[changes]]

## Boundary
- Nothing is posted before the owner approves it. No invented quotes.
- [[one more limit, e.g. no faces of minors without a parent's written yes]]
