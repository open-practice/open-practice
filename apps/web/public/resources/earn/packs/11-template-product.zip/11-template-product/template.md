# Template product: [[What is the template?]]

## Product files
1. [[main file name]] · [[what it is]]
2. [[instructions file]] · start-here steps:
   - Step 1: [[make a copy]]
   - Step 2: [[step]]
   - Step 3: [[step]]
   - Step 4: [[step]]
   - Step 5: [[step]]
3. [[example file filled with invented data]]

## Licence
- You may: [[e.g. use it for your own business, change it]]
- You may not: [[e.g. resell or share the file]]
- Refunds: [[e.g. within 7 days if it does not open or work as described]]

## Listing copy
Title: [[under 60 characters]]
Description: [[two sentences: the problem, and what this template does about it]]
For: [[Who is it for, and what problem does it solve?]]
Included: [[the files above, in buyer words]]
Not for: [[who should not buy it]]
Price: [[Price idea (with currency)]]

## Proof
- Origin: [[Where did it come from?]]
- Validation: [[evidence that others need it, e.g. five people asked for a copy]]
- [[one checkable fact, e.g. works in Google Sheets and Excel; tested on a phone]]

## Boundary
- No income claims, invented reviews or sales numbers. I made every file myself.
- [[one more limit, e.g. not financial or tax advice]]
