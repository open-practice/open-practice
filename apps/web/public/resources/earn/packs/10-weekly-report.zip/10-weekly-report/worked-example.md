> Worked example. The business, people and numbers are invented to show the shape of a finished deliverable.

# Weekly report: a small grocery shop

## Measures
Decisions each week: what to restock, whether to stay open later on Fridays, which supplier to pay first.

- Sales this week vs last week · informs: whether the week was normal · formula: SUMIFS on the Amount column by week
- Top 10 items by quantity · informs: what to restock · formula: a pivot of Item by Quantity, top 10
- Sales after 18:00 on Friday · informs: whether to stay open later · formula: SUMIFS with a time condition
- Supplier bills due within 7 days · informs: who to pay first · formula: FILTER on the Bills tab by due date

Candidates I dropped, and why: "customers per day", because the notebook does not record it.

## Formulas
Data comes from: a sales notebook copied into a sheet each evening
```
=SUMIFS(Sales!C:C, Sales!A:A, ">="&B1, Sales!A:A, "<"&B1+7)
=SUMIFS(Sales!C:C, Sales!A:A, ">="&B1, Sales!B:B, ">=18:00", Sales!D:D, "Fri")
=FILTER(Bills!A:C, Bills!C:C <= TODAY()+7)
```

## QA tests
- Test 1: sales on Monday 3 November · hand count: 214.50 · formula: 214.50 · match
- Test 2: bread loaves sold this week · hand count: 96 · formula: 91 · fixed: five rows typed "Bread " with a space
- Test 3: a week with a public holiday · hand count: 0 for the holiday · formula: 0 · match

## One-page report
- Top line: sales this week, US$1,412, up 6% on last week
- Then: top 10 items, Friday late sales, bills due, each with an arrow up or down
- Last: one sentence, e.g. "Restock bread and cooking oil; pay the dairy supplier by Thursday"

## Boundary
- Every formula was checked against a hand count. Example numbers are invented.
- The report shows what happened. It does not predict sales.
