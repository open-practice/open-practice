# Weekly report: [[Business]]

## Measures
Decisions each week:
[[Which decisions does the owner make each week?]]

- [[measure]] · informs: [[decision]] · formula: [[formula]]
- [[measure]] · informs: [[decision]] · formula: [[formula]]
- [[measure]] · informs: [[decision]] · formula: [[formula]]
- [[measure]] · informs: [[decision]] · formula: [[formula]]

Candidates I dropped, and why: [[which ones did not lead to a decision]]
[[Measures you think matter (one per line)]]

## Formulas
Data comes from: [[Where does the data live now?]]
```
[[formula 1, e.g. =SUMIFS(C:C, A:A, ">="&B1)]]
[[formula 2]]
```

## QA tests
- Test 1: [[what you count by hand]] · hand count: [[number]] · formula: [[number]] · [[match / fixed]]
- Test 2: [[test]] · hand count: [[number]] · formula: [[number]] · [[result]]
- Test 3: [[an empty or odd week]] · hand count: [[number]] · formula: [[number]] · [[result]]

## One-page report
- Top line: [[the one number the owner reads first, compared with last week]]
- Then: [[the other measures, each with an arrow up or down]]
- Last: [[one sentence: what to decide this week]]

## Boundary
- Every formula was checked against a hand count. Example numbers are invented.
- The report shows what happened. It does not predict sales.
