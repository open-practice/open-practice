# Checklist · Build 03 · Customer Reply Kit

- [ ] Every [[blank]] is replaced with your own words
- [ ] Has a “FAQ” section
- [ ] Has a “Response library” section
- [ ] Has a “Escalation matrix” section
- [ ] Has a “Missing information” section
- [ ] Has a “Boundary” section
- [ ] At least 3 FAQ questions (### …)
- [ ] At least 6 library replies (- When …)
- [ ] At least 4 escalation rules (trigger → who → how fast)
- [ ] No phone numbers or email addresses copied in
- [ ] Mentions the business from your brief
- [ ] No hype: no guaranteed results, passive income or overnight claims
- [ ] Between 220 and 1000 words
- [ ] Is every price and policy one the owner confirmed?
- [ ] Would the reply to an upset customer calm you down?
- [ ] Does every escalation say who and how fast, not just “escalate”?
