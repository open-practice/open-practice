> Worked example. The business, people and numbers are invented to show the shape of a finished deliverable.

# Customer reply kit: a home bakery selling cakes to order

## FAQ
Questions customers ask (no names or numbers kept): price, delivery, sugar-free options, how early to order, payment.

### How much is a birthday cake?
Cakes start at US$15 for a 20 cm sponge. Fillings and writing are included; figures and photos cost extra.

### Do you deliver?
Yes, within 5 km for US$2. Further away, you can collect from the house.

### How early do I need to order?
Three days before. For weddings and orders over 30 people, two weeks.

## Response library
Tone: Warm and short
- When someone asks the price: Hello! Birthday cakes start at US$15 for a 20 cm sponge, writing included. What date is it for?
- When someone asks about delivery: We deliver within 5 km for US$2, or you can collect. Which area are you in?
- When you cannot do what they ask: I'm sorry, we can't do that one. We can do a vanilla cake with a printed photo instead. Would that work?
- When an order is confirmed: Thank you! One chocolate cake, 20 cm, "Happy 7th Tino", Saturday at 10:00, US$17 with delivery.
- When someone is upset: Thank you for telling us, and I'm sorry. The owner will call you today to sort it out.
- When you do not know the answer: Good question. Let me check with the baker and reply by 3 pm.

## Escalation matrix
Always handled by a person: complaints, refunds, allergies, anything about money
- The words "allergy", "nuts" or "gluten" → the baker → before the order is accepted
- Any complaint or refund request → the owner → a call the same day
- Orders over 30 people → the owner → within 24 hours
- Payment did not arrive → the owner → within 2 hours

## Missing information
The owner has not confirmed whether sugar-free cakes are possible. Until then, the reply is "let me check".

## Boundary
- Every price and policy here was confirmed by the owner. Nothing invented.
- Customer names, numbers and messages were removed before writing this kit.
