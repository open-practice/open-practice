# Customer reply kit: [[Business and what it sells]]

## FAQ
Questions customers ask (no names or numbers kept):
[[The questions customers ask most (one per line, no names or numbers)]]

### [[question 1, in the customer's words]]
[[answer in 1–3 sentences, using only these facts:]]
[[Facts the owner confirmed (prices, hours, policies)]]

### [[question 2]]
[[answer]]

### [[question 3]]
[[answer]]

## Response library
Tone: [[Tone]]
- When someone asks the price: [[reply under 60 words]]
- When someone asks about delivery: [[reply]]
- When you cannot do what they ask: [[a kind no, with an alternative]]
- When an order is confirmed: [[reply that repeats what, when and how much]]
- When someone is upset: [[reply that thanks them and says a person will call]]
- When you do not know the answer: [[reply that promises a time, not an answer]]

## Escalation matrix
Always handled by a person: [[What must always go to a person?]]
- [[trigger, e.g. the word “refund”]] → [[who]] → [[within how long]]
- [[trigger]] → [[who]] → [[how long]]
- [[trigger]] → [[who]] → [[how long]]
- [[trigger]] → [[who]] → [[how long]]

## Missing information
[[anything a reply needs that the owner has not confirmed yet]]

## Boundary
- Every price and policy here was confirmed by the owner. Nothing invented.
- Customer names, numbers and messages were removed before writing this kit.
