# Article refresh: [[Which article, and how old is it?]]

## Source log
Claims to check:
[[Claims or facts that may be out of date (one per line)]]

- Claim 1: [[the claim]] → [[still true / changed / could not verify]] · source: [[primary source name]] · checked [[date]]
- Claim 2: [[claim]] → [[result]] · source: [[source]] · checked [[date]]
- Claim 3: [[claim]] → [[result]] · source: [[source]] · checked [[date]]

## Changes
1. [[before]] → [[after]] · why: [[reason]]
2. [[before]] → [[after]] · why: [[reason]]
3. [[before]] → [[after]] · why: [[reason]]
- Internal links added or fixed: [[which pages on the same site now link here, or from here]]

## Revised sections
Written for: [[Who reads it, and what do they need?]]
[[the rewritten paragraphs only, in plain language]]

## Change report
For [[Whose is it?]]:
- Changed: [[summary]]
- Kept as it was: [[what still works and why]]
- Please confirm: [[anything only the owner can confirm]]

## Boundary
- Every changed fact has a named source and a date. Nothing is invented.
- An AI tool was not used as a source for any fact.
