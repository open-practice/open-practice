> Worked example. The business, people and numbers are invented to show the shape of a finished deliverable.

# Article refresh: “How to open a market stall” guide, written in 2022

## Source log
Claims to check: the stall licence fee, where to apply, the opening hours rule.

- Claim 1: the licence fee is US$10 a month → changed · source: the town council's 2026 fee schedule · checked 4 November 2026
- Claim 2: apply at the market office → still true · source: phone call to the market office · checked 4 November 2026
- Claim 3: stalls may open at 6:00 → could not verify · source: council by-laws page (not updated since 2023) · checked 4 November 2026

## Changes
1. "US$10 a month" → "US$12 a month (2026 schedule)" · why: the fee went up in January
2. A dead link to the old council site → the current fee schedule page · why: the old link returns an error
3. "Bring three photos" → "Bring two photos and your ID" · why: the market office said so on the phone
- Internal links added or fixed: linked to the blog's budgeting post from step 4, and fixed a link to the old contact page

## Revised sections
Written for: first-time traders who want the steps in order
Step 2 now reads: Go to the market office with two photos and your ID. The licence costs US$12 a month under the 2026 fee schedule. Ask about opening hours when you apply, because the published rule may be out of date.

## Change report
For a community business blog:
- Changed: the fee, one dead link and the documents list
- Kept as it was: the step order and the budgeting section, which are still accurate
- Please confirm: the opening-hours rule, which no current source states

## Boundary
- Every changed fact has a named source and a date. Nothing is invented.
- An AI tool was not used as a source for any fact.
