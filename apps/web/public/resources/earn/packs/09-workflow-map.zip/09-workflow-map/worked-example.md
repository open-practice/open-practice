> Worked example. The business, people and numbers are invented to show the shape of a finished deliverable.

# Workflow: turning order messages into a delivery list each morning

## Process map
Trigger: a new order message on WhatsApp
Steps today: read the message, copy details into a sheet, group by area, send the list to the driver.

1. Order message → copy name, item, area and time into the order form → a new row in the sheet
2. New row → a formula looks up the delivery fee for the area → row with fee
3. [HUMAN] Rows with "special request" → the owner reads and approves or calls the customer → approved rows
4. Approved rows at 07:30 → a filter view sorted by area → the driver's list, shared as view-only

## Test run
Tool: Google Sheets formulas. Sample data: invented, 12 records.
- Test 1 (normal): an order in Avondale for 10:00 · expected: fee US$2, in the Avondale group · actual: as expected
- Test 2 (normal): two orders, same customer · expected: two rows, flagged as same customer · actual: not flagged, fixed with COUNTIF
- Test 3 (unusual): a message with no area · expected: row marked "ask area" · actual: fee showed #N/A, fixed with IFERROR

## Failure plan
- If a step fails: the row turns red and stays off the driver's list
- Who is told: the owner, by a red count at the top of the sheet she checks at 07:15

## Handoff notes
- To run it: fill the form for each order; open the "driver" view at 07:30 and share it
- To stop it: stop using the form; the sheet keeps working as a normal list
- Data stored in: the owner's Google Drive; personal data: customer names, addresses, phone numbers
- Accounts owned by: the owner, in her name

## Boundary
- Tested on invented sample data only. A person decides on every [HUMAN] step.
- It never sends messages to customers by itself.
