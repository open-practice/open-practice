# Checklist · Build 09 · Workflow Map & Test Run

- [ ] Every [[blank]] is replaced with your own words
- [ ] Has a “Process map” section
- [ ] Has a “Test run” section
- [ ] Has a “Failure plan” section
- [ ] Has a “Handoff notes” section
- [ ] Has a “Boundary” section
- [ ] At least 4 mapped steps (input → action → output)
- [ ] Marks at least one human decision
- [ ] At least 3 test cases with expected and actual results
- [ ] Tests an unusual case
- [ ] Explains how to stop it
- [ ] Mentions the task from your brief
- [ ] No hype: no guaranteed results, passive income or overnight claims
- [ ] Between 180 and 1000 words
- [ ] Could someone who never met you run and stop this workflow from the notes?
- [ ] What happens to the unusual case, and does someone find out?
- [ ] Did any real customer data go into the test?
