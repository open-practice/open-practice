# Workflow: [[Which repeated task?]]

## Process map
Trigger: [[What starts it?]]
Steps today:
[[Steps today, in order (one per line)]]

1. [[input]] → [[action]] → [[output]]
2. [[input]] → [[action]] → [[output]]
3. [HUMAN] [[input]] → [[the decision a person makes]] → [[output]]
4. [[input]] → [[action]] → [[output]]

## Test run
Tool: [[Free tool you will prototype with]]. Sample data: invented, [[number]] records.
- Test 1 (normal): [[case]] · expected: [[result]] · actual: [[result]]
- Test 2 (normal): [[case]] · expected: [[result]] · actual: [[result]]
- Test 3 (unusual): [[e.g. a message with no address]] · expected: [[result]] · actual: [[result]]

## Failure plan
- If a step fails: [[what happens, e.g. the order stays in the inbox and is flagged]]
- Who is told: [[person]] by [[how]]

## Handoff notes
- To run it: [[steps]]
- To stop it: [[steps]]
- Data stored in: [[where]]; personal data: [[Personal data involved]]
- Accounts owned by: [[the client, in their name]]

## Boundary
- Tested on invented sample data only. A person decides on every [HUMAN] step.
- [[one more limit, e.g. it never sends messages to customers by itself]]
