# Checklist · Build 04 · Spreadsheet Cleanup Plan

- [ ] Every [[blank]] is replaced with your own words
- [ ] Has a “Safety first” section
- [ ] Has a “Rules log” section
- [ ] Has a “Validation report” section
- [ ] Has a “Handoff” section
- [ ] Has a “Boundary” section
- [ ] At least 3 numbered cleaning rules
- [ ] Reports row counts before and after
- [ ] Works on a copy
- [ ] Includes hand spot checks
- [ ] Mentions the spreadsheet from your brief
- [ ] No hype: no guaranteed results, passive income or overnight claims
- [ ] Between 180 and 900 words
- [ ] Could someone else repeat your clean-up from the rules log alone?
- [ ] Is every removed row listed somewhere?
- [ ] Did any personal data leave the file at any point?
