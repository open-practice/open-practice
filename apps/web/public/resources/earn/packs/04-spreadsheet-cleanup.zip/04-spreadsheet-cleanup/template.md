# Clean-up plan: [[What is the spreadsheet for?]]

## Safety first
- I work on a copy named [[file name]]. The original is never edited.
- Personal data: [[Does it contain personal data? Which columns?]]. [[how you protect it: hide or remove the column before using AI, never paste it anywhere]]
- Size at the start: [[How big is it? (rows and columns)]]

## Rules log
Problems found:
[[What is wrong with it? (one per line)]]

1. [[rule: what you change]] — column [[letter]] — why: [[reason]] — method: [[formula or step]]
2. [[rule]] — column [[letter]] — why: [[reason]] — method: [[formula or step]]
3. [[rule]] — column [[letter]] — why: [[reason]] — method: [[formula or step]]

## Validation report
- Rows before: [[number]] · rows after: [[number]]
- Duplicates removed: [[number]], listed in the tab “removed”
- Values changed: [[number]], listed in the tab “changes”
- Check total before: [[number]] · after: [[number]] · difference explained: [[why]]
- Spot checks (three rows compared by hand): [[row numbers and result]]
- The goal works: [[What must the clean file be able to do?]] → [[the formula or pivot that proves it]]

## Handoff
- The client receives: the cleaned copy, the rules log and this report
- The client must check: [[the one or two things only they can confirm]]

## Boundary
- Nothing was deleted without being listed. The original file is untouched.
- No personal data was pasted into an AI tool.
