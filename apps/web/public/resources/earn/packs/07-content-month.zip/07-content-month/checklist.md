# Checklist · Build 07 · Monthly Content Pack

- [ ] Every [[blank]] is replaced with your own words
- [ ] Has a “Content system” section
- [ ] Has a “Drafts” section
- [ ] Has a “Approval calendar” section
- [ ] Has a “Measures” section
- [ ] Has a “Boundary” section
- [ ] At least 4 weekly drafts (### Week …)
- [ ] At least 8 themes and drafts tied to a fact
- [ ] At least 4 visual briefs (Visual: …)
- [ ] Says what happens if the owner does not reply
- [ ] Mentions the business from your brief
- [ ] No hype: no guaranteed results, passive income or overnight claims
- [ ] Between 220 and 1100 words
- [ ] Is every draft based on a fact the owner gave you?
- [ ] Would the owner recognise their own voice?
- [ ] Is approving the week a single, quick step for the owner?
