> Worked example. The business, people and numbers are invented to show the shape of a finished deliverable.

# Monthly content pack: a tailoring shop that makes work uniforms and suits

## Content system
Real facts: suits ready in 7 days, alterations on clothes bought elsewhere, open since 2015, two tailors with 30 years between them.

- Week 1 theme: behind the seams · based on: two tailors with 30 years between them
- Week 2 theme: fix what you already own · based on: alterations on clothes bought elsewhere
- Week 3 theme: seven days to a suit · based on: suits ready in 7 days
- Week 4 theme: ten years on the same corner · based on: open since 2015
- Never posted: customer photos without a written yes, unconfirmed prices, comments about other shops

## Drafts
Voice: proud of the craft, a bit funny, never pushy

### Week 1
Baba Moyo has been cutting cloth since before most of our customers were born. Mai Tsitsi checks every buttonhole twice. Between them: 30 years and very strong opinions about lapels.
Visual: both tailors at the cutting table, hands only
Based on: two tailors with 30 years between them

### Week 2
Bought a jacket that almost fits? Bring it in. We take in, let out, shorten and rescue clothes from any shop. Your favourite shirt deserves a second life.
Visual: a before-and-after of a jacket taken in at the waist
Based on: alterations on clothes bought elsewhere

### Week 3
Monday: measurements. Wednesday: first fitting. Next Monday: you walk out in a suit made for you. Seven days, no shortcuts.
Visual: three photos, one per fitting day, of the same suit
Based on: suits ready in 7 days

### Week 4
Same corner, same scissors, since 2015. Thank you to everyone who keeps walking up our steps.
Visual: the shop front in morning light
Based on: open since 2015

## Approval calendar
Channel: Facebook page and WhatsApp Status, 3 times a week
- Drafts sent to the owner every Friday by 16:00
- Owner replies by Sunday; no reply means nothing is posted
- Posting days: Monday, Wednesday, Friday

## Measures
- Enquiries that mention a post, counted in a notebook at the counter
- Alteration jobs per week, compared with last month

## Boundary
- Every post is based on a fact the owner confirmed. No invented offers, prices or reviews.
- Nothing is posted without the owner's approval.
