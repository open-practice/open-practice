# Journey audit: [[Which business, and did they ask for this?]]

## Journey
Customer goal: [[What is the customer trying to do?]]
Steps taken:
[[Steps you took, in order (one per line)]]

1. [[step]] → [[what happened]] · evidence: [[screenshot name, time and date]]
2. [[step]] → [[what happened]] · evidence: [[evidence]]
3. [[step]] → [[what happened]] · evidence: [[evidence]]
4. [[step]] → [[what happened]] · evidence: [[evidence]]

## Evidence pack
Problems seen:
[[What went wrong or was slow?]]
Stored in: [[folder name]] · [[number]] screenshots, all from public pages or with permission

## Prioritised fixes
- [[fix]] · impact: [[high/medium/low]] · effort: [[high/medium/low]] · why: [[reason]]
- [[fix]] · impact: [[impact]] · effort: [[effort]] · why: [[reason]]
- [[fix]] · impact: [[impact]] · effort: [[effort]] · why: [[reason]]
- [[fix]] · impact: [[impact]] · effort: [[effort]] · why: [[reason]]

## Mini-demo
Top fix: [[the fix]]
Before: [[what a customer sees now]]
After: [[what they would see]]

## Boundary
- Only public touchpoints were used, or the business asked for this audit. No fake enquiries that waste staff time.
- I report what I observed. I do not guess at the business's sales or numbers.
