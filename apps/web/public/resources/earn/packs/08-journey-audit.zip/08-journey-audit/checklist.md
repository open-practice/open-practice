# Checklist · Build 08 · Customer Journey Audit

- [ ] Every [[blank]] is replaced with your own words
- [ ] Has a “Journey” section
- [ ] Has a “Evidence pack” section
- [ ] Has a “Prioritised fixes” section
- [ ] Has a “Mini-demo” section
- [ ] Has a “Boundary” section
- [ ] At least 4 journey steps with evidence
- [ ] At least 4 fixes rated for impact and effort
- [ ] Mini-demo shows before and after
- [ ] Mentions the customer goal from your brief
- [ ] No hype: no guaranteed results, passive income or overnight claims
- [ ] Between 200 and 1000 words
- [ ] Could the owner repeat every step and see the same thing?
- [ ] Is the top fix high impact and low effort, or did you choose the interesting one?
- [ ] Did you avoid wasting staff time with fake requests?
