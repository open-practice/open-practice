> Worked example. The business, people and numbers are invented to show the shape of a finished deliverable.

# Page kit: Tendai’s Shoe Repairs, a shoe and bag repair stall

## Page copy
Headline: Shoe and bag repairs while you shop
One line: Heels, zips and straps fixed at the Fife Avenue market, most jobs ready the same day.

Services and prices:
- Heel replacement — US$5
- Zip repair — US$4
- Bag strap — US$3
- Resole (leather) — US$12

Where and when: Fife Avenue market, row C, Mon–Sat 8:00–17:00
Contact button: “WhatsApp Tendai to book” → WhatsApp only, replies within the hour
Proof shown on the page: four before-and-after photos Tendai took of real repairs

## Demo test plan
- Phone test: on a budget Android phone with mobile data, the text showed in 2 seconds and the photos in 4
- Contrast: all text readable outdoors at noon; the grey caption was too light, so it is now dark brown
- Contact test: the button opened WhatsApp with “Hello Tendai, I need a repair:” ready to send
- Links: 3 links, all open; the map link pointed to the wrong row and was fixed
- Facts: Tendai checked every price, the hours and the number on 4 November

## Launch checklist
- [x] Owner approved the copy in writing
- [x] Prices and phone number checked against the owner's list
- [x] Page loads on a phone in under 3 seconds
- [x] Every image is the owner's own, or free to use, and has alt text
- [x] Contact button tested from a second phone
- [x] The free web address is registered in the owner's name
- [x] Opening hours repeated next to the button for Saturday shoppers
- [ ] Handoff note sent and read

## Client handoff
- To change a price: open the page editor, find the price list, change the number, press Publish. It takes two minutes.
- Who owns what: the web address and the hosting account are in Tendai's name, with his email.
- What may cost money later: nothing, unless he buys a custom domain (about US$12 a year).
- How to get help: WhatsApp me; small text changes are free for the first month.

## Boundary
- No invented reviews, awards or customer numbers. Only proof the owner gave permission for.
- I do not run paid adverts or manage his WhatsApp.
