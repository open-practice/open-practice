# Checklist · Build 01 · Offer Sheet Builder

- [ ] Every [[blank]] is replaced with your own words
- [ ] Has a “Niche brief” section
- [ ] Has a “Problem interview” section
- [ ] Has a “The offer” section
- [ ] Has a “Price hypothesis” section
- [ ] Has a “Boundary” section
- [ ] At least 5 numbered interview questions
- [ ] Lists exclusions
- [ ] Timeline names a number of days
- [ ] First price is a real number
- [ ] Mentions the buyer from your brief
- [ ] No hype: no guaranteed results, passive income or overnight claims
- [ ] Between 200 and 900 words
- [ ] Could you name five real people who match the buyer line?
- [ ] Are the interview questions about past events, not “would you buy”?
- [ ] Would you be comfortable reading the boundary out loud to a buyer?
