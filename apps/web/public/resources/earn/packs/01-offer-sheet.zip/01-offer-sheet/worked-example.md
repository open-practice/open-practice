> Worked example. The business, people and numbers are invented to show the shape of a finished deliverable.

# Offer sheet: a quick-reply set and booking script for hair salon owners in Avondale

## Niche brief
- Buyer: hair salon owners in Avondale with two to six chairs
- The job they hate: WhatsApp booking enquiries go unanswered on busy Saturdays
- Where I can reach five of them this week: the salons on the two shopping rows I pass every day
- Why me: I keep tidy spreadsheets and write clear WhatsApp messages for my church group

## Problem interview
1. Tell me about the last Saturday when enquiries piled up. What did you do?
2. How many of those people booked somewhere else, as far as you know?
3. What have you tried already: a helper on the phone, a booking app, anything else?
4. Who answers the business phone, and who would pay to fix this?
5. If this were solved, what would be different next month?

Notes after the interviews: four of five owners said Saturday mornings are the worst. Two said “by the time I answer, they have gone to the next salon”. One already uses quick replies and did not see a problem.

## The offer
- What you get: a set of 12 WhatsApp Business quick replies, a booking script for the person on the phone, and a one-page price list image
- Exclusions: no booking software, no paid adverts, no managing the phone for you
- Timeline: 3 days from yes to delivery
- Revisions: 2 rounds
- What I need from you: 30 minutes to list your services and prices, and your current greeting message

## Price hypothesis
- First price: US$40 one-off setup
- Why this number: about four hours of work at US$10 an hour, and less than the value of two lost bookings
- How I will test it: say the price to the five owners I interviewed and count who asks how to start
- I will change the price if: four or more say yes at once, then the next offer is US$55

## Boundary
- No guaranteed results, no invented testimonials and no fake deadlines.
- I will not message the salon's customers myself or see their contact list.

## Evidence so far
Two owners told me on 3 November that they lose Saturday bookings.
I counted unanswered enquiries with one owner's permission: 9 waited more than an hour last Saturday.
